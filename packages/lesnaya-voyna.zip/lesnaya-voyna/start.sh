#!/bin/sh
# Запуск «Лесной войны»: локальный сервер, затем откройте http://localhost:8080
cd "$(dirname "$0")" && echo "Открой http://localhost:8080 (Ctrl+C — остановить)" && python3 tools/serve.py 8080
