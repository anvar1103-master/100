@echo off
chcp 65001 >nul
rem Запуск «Лесной войны»: локальный сервер + браузер. Нужен установленный Python (python.org).
cd /d "%~dp0"
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8080"
echo Лесная война: http://localhost:8080  (закройте это окно, чтобы остановить)
python tools\serve.py 8080
